# ench.fy 🔍

An elegant, lightweight, open-source search engine built for speed and simplicity. **ench.fy** indexes content locally and provides a clean interface to search through your documents or web data.

## 🚀 Features
* **Full-Text Indexing:** Fast text tokenization and indexing using SQLite FTS5.
* **Modern Web Interface:** Clean HTML/CSS frontend with high readability.
* **REST API:** Simple JSON endpoints for integrating search into other applications.
* **Extensible Scraper:** Python-based helper to ingest markdown or text files.

## 📦 Tech Stack
* **Backend:** Python, Flask
* **Database:** SQLite (with FTS5 Full-Text Search extension)
* **Frontend:** Vanilla HTML5, CSS3 (Tailwind CSS via CDN)

## 🛠️ Getting Started

### 1. Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/ench.fy.git
cd ench.fy
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Initialize & Populate the Database
Run the helper script to create the search index and add some sample data:
```bash
python init_db.py
```

### 4. Run the Search Engine
```bash
python app.py
```
Open `http://127.0.0.1:5000` in your web browser!

## 🤝 Contributing
Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License
This project is licensed under the MIT License.
