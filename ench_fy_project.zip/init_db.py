import sqlite3

DB_FILE = "ench_fy.db"

def init_database():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    # Drop older table if exists
    cursor.execute("DROP TABLE IF EXISTS documents")
    
    # Create Full-Text Search (FTS5) table for fast indexing
    cursor.execute("""
        CREATE VIRTUAL TABLE documents USING fts5(
            title,
            url UNINDEXED,
            content
        )
    """)
    
    # Insert sample documentation mock data
    sample_data = [
        ("Ench.fy Documentation", "https://github.com/ench-fy", "Welcome to ench.fy, the lightning-fast open source search engine project. Learn how to configure indexes, deploy to GitHub, and parse web data configurations."),
        ("Getting Started with Python Flask", "https://flask.palletsprojects.com/", "Flask is a lightweight WSGI web application framework in Python. It is designed to make getting started quick and easy, with the ability to scale up to complex applications."),
        ("SQLite FTS5 Extension Guide", "https://www.sqlite.org/fts5.html", "SQLite FTS5 is a virtual table module that provides full-text search capability to database applications. It allows users to efficiently search documents for specific words or phrases."),
        ("Open Source Community Guide", "https://opensource.guide/", "Open source software is software with source code that anyone can inspect, modify, and enhance. Contributing to open source projects builds real-world software skills.")
    ]
    
    cursor.executemany("INSERT INTO documents (title, url, content) VALUES (?, ?, ?)", sample_data)
    conn.commit()
    conn.close()
    print("Database initialized successfully with sample data!")

if __name__ == "__main__":
    init_database()
